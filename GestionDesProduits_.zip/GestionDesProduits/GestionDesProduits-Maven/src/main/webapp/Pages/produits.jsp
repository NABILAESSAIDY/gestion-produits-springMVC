<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <title>Gestion des Produits | Spring MVC</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 30px;
            background-color: #f5f5f5;
        }
        h1 {
            color: #333;
            border-bottom: 2px solid #4CAF50;
            padding-bottom: 10px;
        }
        form {
            background: #fff;
            padding: 15px;
            margin-bottom: 15px;
            border-radius: 5px;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        input[type="text"] {
            padding: 6px 10px;
            border: 1px solid #ccc;
            border-radius: 4px;
            margin: 3px;
        }
        input[type="submit"] {
            padding: 7px 16px;
            background-color: #4CAF50;
            color: white;
            border: none;
            border-radius: 4px;
            cursor: pointer;
        }
        input[type="submit"]:hover {
            background-color: #45a049;
        }
        table {
            width: 70%;
            border-collapse: collapse;
            background: #fff;
            box-shadow: 0 1px 3px rgba(0,0,0,0.1);
        }
        th {
            background-color: #4CAF50;
            color: white;
            padding: 10px;
        }
        td {
            padding: 8px 12px;
            border: 1px solid #ddd;
        }
        tr:nth-child(even) { background-color: #f9f9f9; }
        a { color: #e53935; text-decoration: none; margin: 0 5px; }
        a.edit-link { color: #1565C0; }
        a:hover { text-decoration: underline; }
        label { font-weight: bold; margin-right: 5px; }
        .section-title { color: #555; font-size: 14px; margin-bottom: 5px; }
    </style>
</head>
<body>

<h1>Gestion des produits | Spring MVC</h1>

<!-- ============================= -->
<!-- Formulaire de recherche       -->
<!-- ============================= -->
<p class="section-title">Recherche :</p>
<form action="searchProduct.aspx" method="post">
    <label>ID :</label>
    <input type="text" name="idProduit" value="${idProduit}" />
    <input type="submit" value="Afficher" />
</form>

<hr/>

<!-- ============================= -->
<!-- Formulaire Ajouter / Modifier -->
<!-- ============================= -->
<p class="section-title">Ajouter / Modifier :</p>
<form action="${produitEdit != null ? 'updateProduit' : 'addProduct'}.aspx" method="post">
    <input type="hidden" name="idProduit" value="${produitEdit != null ? produitEdit.idProduit : ''}" />
    <label>Nom :</label>
    <input type="text" name="nom" value="${produitEdit != null ? produitEdit.nom : ''}" />
    <label>Description :</label>
    <input type="text" name="description" value="${produitEdit != null ? produitEdit.description : ''}" />
    <label>Prix :</label>
    <input type="text" name="prix" value="${produitEdit != null ? produitEdit.prix : ''}" />
    <input type="submit" value="${produitEdit != null ? 'Mettre à jour' : 'Ajouter'}" />
</form>

<hr/><br/>

<!-- ============================= -->
<!-- Tableau des produits          -->
<!-- ============================= -->
<table border="1">
    <tr>
        <th>ID</th>
        <th>NOM</th>
        <th>DESCRIPTION</th>
        <th>PRIX</th>
        <th colspan="2">Options</th>
    </tr>
    <c:forEach items="${listeProduit}" var="o">
        <tr>
            <td>${o.idProduit}</td>
            <td>${o.nom}</td>
            <td>${o.description}</td>
            <td>${o.prix}</td>
            <td><a href="deleteProduit.aspx?id=${o.idProduit}">supprimer</a></td>
            <td><a class="edit-link" href="editProduit.aspx?id=${o.idProduit}">Modifier</a></td>
        </tr>
    </c:forEach>
</table>

</body>
</html>
