package dao;

import java.util.ArrayList;
import java.util.List;

public class ProduitImpl implements ProduitDAO {

    private List<Produit> produits = new ArrayList<Produit>();

    public void init() {
        System.out.println("Spring IOC est bien fonctionnée !");
        addProduit(new Produit("PC 1", "Sony vaio 1", 7000.0));
        addProduit(new Produit("PC 2", "Sony vaio 2", 6000.0));
        addProduit(new Produit("PC 3", "Sony vaio 3", 4000.0));
        addProduit(new Produit("PC 4", "Sony vaio 4", 9000.0));
        addProduit(new Produit("PC 5", "Sony vaio 5", 8000.0));
        addProduit(new Produit("PC 6", "Sony vaio 6", 5000.0));
        addProduit(new Produit("PC 7", "Sony vaio 7", 3000.0));
    }

    @Override
    public void addProduit(Produit p) {
        p.setIdProduit(new Long(produits.size() + 1));
        produits.add(p);
    }

    @Override
    public void deleteProduit(Long id) {
        Produit toRemove = getProduitById(id);
        if (toRemove != null) {
            produits.remove(toRemove);
        }
    }

    @Override
    public Produit getProduitById(Long id) {
        for (Produit p : produits) {
            if (p.getIdProduit().equals(id)) {
                return p;
            }
        }
        return null;
    }

    @Override
    public List<Produit> getAllProduits() {
        return produits;
    }

    @Override
    public void updateProduit(Produit p) {
        for (int i = 0; i < produits.size(); i++) {
            Produit existing = produits.get(i);
            if (existing.getIdProduit().equals(p.getIdProduit())) {
                existing.setNom(p.getNom());
                existing.setDescription(p.getDescription());
                existing.setPrix(p.getPrix());
                break;
            }
        }
    }
}
