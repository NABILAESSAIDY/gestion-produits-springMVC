# Gestion des Produits - Spring MVC

Projet CRUD complet : Spring MVC + Spring IOC + JSP + JSTL
Développé par : Mohamed CHERRADI - ENSA Hoceima, UAE

---

## 📋 Prérequis

- Eclipse IDE for Enterprise Java Developers (2020-06 ou plus récent)
- Apache Tomcat 9.x
- JDK 8 ou 11
- Maven (intégré dans Eclipse via m2e)

---

## 🚀 Import dans Eclipse

### Étape 1 : Importer le projet
1. Ouvrir Eclipse
2. **File → Import → Maven → Existing Maven Projects**
3. Cliquer **Browse** et sélectionner le dossier `GestionDesProduits`
4. Cocher `pom.xml` dans la liste
5. Cliquer **Finish**
6. Attendre que Eclipse télécharge les dépendances (Maven)

### Étape 2 : Configurer Tomcat dans Eclipse
1. **Window → Preferences → Server → Runtime Environments**
2. Cliquer **Add** → Apache Tomcat v9.0
3. Pointer vers votre dossier Tomcat (ex: `C:\apache-tomcat-9.0.x`)
4. Valider

### Étape 3 : Ajouter le projet au serveur Tomcat
1. Dans la vue **Servers**, faire clic droit sur Tomcat → **Add and Remove**
2. Sélectionner **GestionDesProduits** → **Add >>**
3. Cliquer **Finish**

### Étape 4 : Lancer l'application
1. Clic droit sur le serveur Tomcat → **Start**
2. Ouvrir le navigateur : **http://localhost:8080/GestionDesProduits/**

---

## 📂 Structure du projet

```
GestionDesProduits/
├── pom.xml                          ← Dépendances Maven
├── src/main/java/
│   ├── dao/
│   │   ├── Produit.java             ← Classe modèle (entité)
│   │   ├── ProduitDAO.java          ← Interface DAO
│   │   └── ProduitImpl.java         ← Implémentation DAO (en mémoire)
│   ├── services/
│   │   ├── ProduitMetier.java       ← Interface Service
│   │   └── ProduitImplMetier.java   ← Implémentation Service
│   └── controller/
│       └── ProduitController.java   ← Contrôleur Spring MVC
└── src/main/webapp/
    ├── index.jsp                    ← Page d'accueil (redirect)
    ├── Pages/
    │   └── produits.jsp             ← Vue principale (JSP + JSTL)
    └── WEB-INF/
        ├── web.xml                  ← Déploiement web
        ├── spring-beans.xml         ← Config IoC (DAO + Services)
        └── application-servlet-config.xml  ← Config MVC (Controllers + ViewResolver)
```

---

## 🔧 Architecture

```
[Browser] → DispatcherServlet → ProduitController → ProduitImplMetier → ProduitImpl
                                        ↓
                              ViewResolver → produits.jsp
```

### Fichiers de configuration
| Fichier | Rôle |
|---------|------|
| `web.xml` | Configuration globale : DispatcherServlet, mapping `*.aspx` |
| `spring-beans.xml` | IoC XML : beans DAO et Service |
| `application-servlet-config.xml` | IoC Annotations : scan @Controller, ViewResolver |

---

## 🌐 URLs disponibles

| URL | Description |
|-----|-------------|
| `/GestionDesProduits/` | Page principale (liste des produits) |
| `/GestionDesProduits/index.aspx` | Liste de tous les produits |
| `/GestionDesProduits/searchProduct.aspx?idProduit=1` | Rechercher par ID |
| `/GestionDesProduits/addProduct.aspx` | Ajouter un produit (POST) |
| `/GestionDesProduits/editProduit.aspx?id=1` | Formulaire de modification |
| `/GestionDesProduits/updateProduit.aspx` | Mettre à jour (POST) |
| `/GestionDesProduits/deleteProduit.aspx?id=1` | Supprimer un produit |

---

## ⚠️ Remarque

Les données sont stockées **en mémoire** (pas de base de données).
Elles sont réinitialisées à chaque redémarrage du serveur Tomcat.
